
# Создание таблицы для должностей
create_table_positions = "CREATE TABLE `positions` (id INTEGER PRIMARY KEY AUTO_INCREMENT," \
                     " name TEXT NOT NULL," \
                     " salary REAL NOT NULL," \
                     " employee_id int);"
# Создание таблицы для сотрудников
create_table_employees = "CREATE TABLE `employees` (id INTEGER PRIMARY KEY AUTO_INCREMENT," \
                     " name TEXT NOT NULL," \
                     " position_id INTEGER NOT NULL," \
                     " email varchar(32)," \
                     " password varchar(32)," \
                     " FOREIGN KEY (position_id) REFERENCES positions (id))"

create_table_salary_payments = "CREATE TABLE `salary_payments` (id INTEGER PRIMARY KEY AUTO_INCREMENT," \
                     " employee_id INTEGER NOT NULL," \
                     " payment_date DATE NOT NULL," \
                     " base_salary REAL NOT NULL," \
                     " work_days INTEGER NOT NULL," \
                     " bonus REAL DEFAULT 0," \
                     " total_salary REAL NOT NULL," \
                     " FOREIGN KEY (employee_id) REFERENCES employees (id))"

insert_positions = "INSERT INTO  positions  (name, salary, employee_id) VALUES " \
                   "('Менеджер', 100000, 1 )," \
                   "('Фармацевт', 50000, 2 );"\


insert_employees = "INSERT INTO employees (name, position_id, email, password) VALUES" \
              " ('Иван Иванов', 1, 'aa@mai.ru', 'ss'), " \
              "('Петр Петров', 1, 'rr@mai.ru', 'ss')," \
              "('Анна Сидорова', 2, 'ss@mai.ru', 'ss'),"\
              "('Ольга Иванова', 2, 'uu@mai.ru', 'ss');"\

insert_salary_payments = "INSERT INTO salary_payments (employee_id, payment_date, base_salary, work_days, bonus, total_salary) VALUES" \
              " ( 1, '2023-05-01', 10000.00, 37, 2000.00, 100000), " \
              " ( 2, '2023-04-01', 10000.00, 67, 1000.00, 50000); " \


# # создание представлений
# view_positions ="CREATE VIEW positions_view AS SELECT name, salary FROM positions;"
# view_employees = "CREATE VIEW employees_view AS SELECT e.name AS employee_name, p.name AS position_name, p.salary FROM employees e JOIN positions p ON e.position_id = p.id;"
# view_salary_payments = "CREATE VIEW salary_payments_view AS SELECT employee_id, SUM(total_salary) AS total_salary_paid FROM salary_payments GROUP BY employee_id;"
#
# #вызов предстаавлений
# call_positions_view = "SELECT * FROM view_positions;"
# call_employees_view = "SELECT * FROM view_employees;"
# call_salary_payments_view = "SELECT * FROM view_salary_payments;"

# Задание 3 CREATE PROCEDURE CalculateAnnualSalary()
# BEGIN
#     DECLARE total_work_days INT DEFAULT 240; -- 20 рабочих дней в месяце * 12 месяцев
#     DECLARE bonus_percent DECIMAL(5,2) DEFAULT 0.15; -- 15% премии
#     DECLARE bonus_employees INT DEFAULT 2; -- 2 сотрудника получают премию каждый квартал
#     DECLARE bonus_times INT DEFAULT 4; -- премия начисляется 4 раза в год (каждый квартал)
#
#     -- Создаем временную таблицу для хранения результатов
#     CREATE TEMPORARY TABLE IF NOT EXISTS AnnualSalary AS (
#         SELECT
#             e.id AS employee_id,
#             e.name AS employee_name,
#             p.name AS position_name,
#             (p.salary * total_work_days / 20) AS base_annual_salary, -- базовая годовая зарплата
#             (p.salary * bonus_percent * bonus_times) AS bonus, -- годовая сумма премий
#             ((p.salary * total_work_days / 20) + (p.salary * bonus_percent * bonus_times)) AS total_annual_salary -- общая годовая зарплата
#         FROM
#             employees e
#         INNER JOIN
#             positions p ON e.position_id = p.id
#     );
#
#     -- Выводим результаты
#     SELECT * FROM AnnualSalary;
#
#     -- Удаляем временную таблицу
#     DROP TABLE AnnualSalary;
# END //
# DELIMITER ;
