import connDB
from connDB import connection
import query_sql
try:
    with connection.cursor() as cursor:
        # создание таблицы positions
        cursor.execute(query_sql.create_table_positions)
        connection.commit()
        # создание таблицы employees
        cursor.execute(query_sql.create_table_employees)
        connection.commit()
        # создание таблицы salary_payments
        cursor.execute(query_sql.create_table_salary_payments)
        connection.commit()

        cursor.execute(query_sql.insert_positions)
        connection.commit()

        cursor.execute(query_sql.insert_employees)
        connection.commit()

        cursor.execute(query_sql.insert_salary_payments)
        connection.commit()


        # #Create Views
        cursor.execute(query_sql.view_positions)
        connection.commit()

        cursor.execute(query_sql.view_employees)
        connection.commit()

        cursor.execute(query_sql.view_salary_payments)
        connection.commit()




        print("Complite all ")

finally:
    connection.close()





