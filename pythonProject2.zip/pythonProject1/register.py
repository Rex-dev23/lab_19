import pymysql
from connDB import connection
import validation

try:
    with connection.cursor() as cursor:
        while True:
            choice = input("Для добавления новой должности нажмите 1, для расчета зарплаты сотрудников нажмите 2 для регестация нажмите 3: ")
            if choice == "1":
                # Блок кода для добавления должностей
                for i in range(2):
                    name = input(f"Введите название новой должности {i+1}: ")
                    salary = float(input(f"Введите зарплату для новой должности {i+1}: "))
                    employee_id = float(input(f"Введите номер своей должности {i+1}: "))
                    # Добавление новой должности
                    insert_position_query = f"INSERT INTO positions (name, salary, employee_id) VALUES ('{name}', {salary}, {employee_id})"
                    cursor.execute(insert_position_query)

                # Блок кода для добавления сотрудников
                for i in range(4):
                    name1 = input(f"Введите имя сотрудника {i + 1}: ")
                    position_id = input(f"Введите идентификатор должности для сотрудника {i + 1}: ")
                    email = input(f"Введите почту для сотрудника {i + 1}: ")
                    password = input(f"Введите пароль для сотрудника {i + 1}: ")
                    insert_employee_query = f"INSERT INTO employees (name, position_id, email, password) VALUES ('{name1}', '{position_id}', '{email}', '{password}')"
                    cursor.execute(insert_employee_query)
                    connection.commit()

            elif choice == "2":
                confirm = input("Вы уверены, что хотите произвести расчет зарплаты сотрудников? (да/нет): ")
                if confirm.lower() == "да":
                    calculate_salary_query = "SELECT " \
                                             "e.name AS employee_name, " \
                                             "p.name AS position_name, " \
                                             "sp.base_salary AS base_annual_salary, " \
                                             "sp.bonus AS bonus, " \
                                             "sp.total_salary AS total_annual_salary " \
                                             "FROM salary_payments sp " \
                                             "JOIN employees e ON sp.employee_id = e.id " \
                                             "JOIN positions p ON e.position_id = p.id"
                    cursor.execute(calculate_salary_query)
                    salaries = cursor.fetchall()

                    if len(salaries) > 0:
                        print("Расчет зарплаты сотрудников:")
                        print()
                        for salary in salaries:
                            print(f"Сотрудник: {salary['employee_name']}")
                            print(f"Должность: {salary['position_name']}")
                            print(f"Базовая годовая зарплата: {salary['base_annual_salary']}")
                            print(f"Премия: {salary['bonus']}")
                            print(f"Общая годовая зарплата: {salary['total_annual_salary']}")
                            print()
                    else:
                        print("Нет информации о зарплатах сотрудников.")
                else:
                    print("Расчет зарплаты сотрудников отменен.")

                break


            elif choice == "3":
                print("Регистрация в личном кабинете: ")
                name = input("Введите имя: ")
                while True:
                    password = input('Введите пароль: ')
                    if validation.is_valid_password(password):
                        print('Пароль надежный.')
                        break
                    else:
                        print('Пароль ненадежный! ')

                email = input("Введите почту:")
                position_id = input("Введиет номер своей должности")
                user_reg = f"INSERT INTO employees(email, password, name, position_id) VALUES ('{email}', MD5('{password}'), '{name}', '{position_id}')"
                cursor.execute(user_reg)
                connection.commit()
                print("Регистрация выполнена успешно!")

finally:
    connection.close()
